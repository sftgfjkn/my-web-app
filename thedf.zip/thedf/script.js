// Toggle between login and signup forms
document.getElementById('signup-link').addEventListener('click', function(event) {
  event.preventDefault();
  document.getElementById('signup-form').classList.toggle('hidden');
});

// Simulate login success and navigate to the "Hello Daters" page after 3 seconds
document.getElementById('login-form').addEventListener('submit', function(event) {
  event.preventDefault();
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;

  // Simulate successful login (Replace this with actual login functionality)
  if (email && password) {
    document.getElementById('login-success').classList.remove('hidden');
    setTimeout(function() {
      document.getElementById('login-success').classList.add('hidden');
      window.location.href = 'hello-daters.html'; // Redirect to Hello Daters page
    }, 3000); // Show the login success screen for 3 seconds
  }
});
